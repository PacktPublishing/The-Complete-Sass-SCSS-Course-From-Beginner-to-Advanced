require 'susy'
require 'breakpoint'
#require 'compass'

preferred_syntax = :scss
http_path = '/'
css_dir = 'css'
sass_dir = 'scss'
images_dir = 'images'
javascripts_dir = 'js'
relative_assets = true
line_comments = true
#output_style = :compressed